//This section updates the graphics and responds to key events

//import statments
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class RandomGenRun extends JFrame
    implements KeyListener {
//setting drawpanel and initializing variables
    public RandomGenRun() {
        super("Flight");
        panel = new RandomGen();
        add(panel);
        addKeyListener(this);
        high=0;
        nhigh=false;
        speed=0;
        
    }
//updates graphics
    public void go() {
        do {
            if (!panel.jumpahead){
            try {
                Thread.sleep(20L);
            }
            catch(InterruptedException interruptedexception) { }
            update(getGraphics());
            }
            if (panel.jumpahead){
            try {
                Thread.sleep(3L);
            }
            catch(InterruptedException interruptedexception) { }
            update(getGraphics());    
            }
            } while(!panel.die);
        //calls read and write file
        if (panel.die){  
            String file_name = "/Users/Danweb/Desktop/Flight/highs.txt";
        //gets highscore from file
        try {
            ReadFile file = new ReadFile(file_name);
            String[] aryLines = file.OpenFile();
            
            high = Integer.parseInt(aryLines[0]);
            //compares highscore to current score
            if (panel.score>high){
                high=panel.score;
                nhigh=true;
            }
            //writes the highscore to file, wether new or old
            String hs = String.format("%s", high);
            
            
            WriteFile data = new WriteFile(file_name, true);
            data.writeToFile(hs);
        
        }
        catch (IOException e){
            System.out.println( e.getMessage() );
            
        
        }
            try {
                Thread.sleep(100L);
            }
            catch(InterruptedException interruptedexception) { }
            int fscore=panel.score;
            JOptionPane.showMessageDialog(null, "Your Final Score Was: "+fscore, "Score", JOptionPane.INFORMATION_MESSAGE);
            if (!nhigh)
            JOptionPane.showMessageDialog(null, "Highscore: "+high, "Highscore", JOptionPane.INFORMATION_MESSAGE);
            if (nhigh)
            JOptionPane.showMessageDialog(null, "You Got a New Highscore of: "+high, "New Highscore", JOptionPane.INFORMATION_MESSAGE);
            try {
                Thread.sleep(500L);
            }
            catch(InterruptedException interruptedexception) { }
            
            System.exit(0);
        }
        
    }
//setting panel size and elements
    public static void main(String args[]) throws IOException{
        RandomGenRun randomgenrun = new RandomGenRun();
        randomgenrun.setSize(500, 500);
        randomgenrun.setDefaultCloseOperation(3);
        randomgenrun.setLocation(500, 200);
        randomgenrun.setVisible(true);
        randomgenrun.setBackground(Color.BLACK);
        randomgenrun.go();
        
    }
//watching for key events
    public void keyPressed(KeyEvent keyevent) {
        switch(keyevent.getKeyCode()) {
        case 32: // ' '
            panel.space = true;
            break;
        case 80:
            panel.pause=true;
            break;
        }
    }

    public void keyReleased(KeyEvent keyevent) {
        switch(keyevent.getKeyCode()) {
        case 32: // ' '
            panel.space = false;
            break;
        case 80:
            panel.pause = false;
            break;
        }
        
    }

    public void keyTyped(KeyEvent keyevent) {
    }
    //creating variables
    RandomGen panel;
    int high;
    int speed;
    boolean nhigh;
    
}
