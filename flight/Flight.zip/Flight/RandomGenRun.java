//This class updates the graphics and responds to key events

//import statments
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class RandomGenRun extends JFrame implements KeyListener {
    
    private static String play_check = "";
    
    //setting drawpanel and initializing variables
    public RandomGenRun() {
        super("Flight");
        panel = new RandomGen();
        add(panel);
        addKeyListener(this);
        high=0;
        nhigh=false;
        speed=0;
        
    }
    
    //updates graphics
    public void go() {
        do {
            if (!panel.jumpahead){
                try {
                    Thread.sleep(20);
                }
                catch(InterruptedException interruptedexception) { }
                repaint();
                //update(getGraphics());
            }
            if (panel.jumpahead){
                try {
                    Thread.sleep(3);
                }
                catch(InterruptedException interruptedexception) { }
                repaint();
                //update(getGraphics());    
            }
            
            //calls read and write file
            if (panel.die){
                String filePath = new File("").getAbsolutePath();
                String file_name = filePath.concat("/info.txt");
                //gets highscore from file
                try {
                    ReadFile file = new ReadFile(file_name);
                    String[] aryLines = file.OpenFile();

                    high = Integer.parseInt(aryLines[0]);
                    //compares highscore to current score
                    if (panel.score>high){
                        high=panel.score;
                        nhigh=true;
                    }
                    //writes the highscore to file, whether new or old
                    String hs = String.format("%s", high);


                    WriteFile data = new WriteFile(file_name, true);
                    data.writeToFile(hs+"\nyes");

                }
                catch (IOException e){System.out.println(e.getMessage());}
                int fscore=panel.score;
                JOptionPane.showMessageDialog(null, "Your Final Score Was: "+fscore, "Score", JOptionPane.INFORMATION_MESSAGE);
                if (!nhigh)
                JOptionPane.showMessageDialog(null, "Highscore: "+high, "Highscore", JOptionPane.INFORMATION_MESSAGE);
                if (nhigh)
                JOptionPane.showMessageDialog(null, "You Got a New Highscore of: "+high, "New Highscore", JOptionPane.INFORMATION_MESSAGE);
                int resp=
                        JOptionPane.showConfirmDialog(null, "Play Again?", "Play Again?", JOptionPane.YES_NO_OPTION);
                if (resp == JOptionPane.YES_OPTION){
                    panel.reset = true;
                    panel.die = false;
                }
                else {

                    System.exit(0);
                }
            }
        } while(true);  
    }
    
    //setting panel size and elements
    public static void main(String args[]) throws IOException{
        RandomGenRun randomgenrun = new RandomGenRun();
        randomgenrun.setSize(500, 500);
        randomgenrun.setDefaultCloseOperation(3);
        randomgenrun.setLocation(500, 200);
        randomgenrun.setVisible(true);
        //set filepath
        String filePath = new File("").getAbsolutePath();
        String file_name = filePath.concat("/info.txt");

        //get highscore from file
        try {
            ReadFile file = new ReadFile(file_name);
            String[] aryLines = file.OpenFile();
            
            play_check = aryLines[1];
        }

        catch (IOException e){
            System.out.println( e.getMessage() );
        }
        
        if ("no".equals(play_check)){
            JOptionPane.showMessageDialog(null, "How To Play:\nUse The Space Bar To Move Up And Down\nAvoid The Green Landscape And Barriers\nCollect Yellow Score Multipliers To Boost Your Score\nCollet White Health Packs When Your Shields Are Down\nCollect Orange JumpAheads To Get Easy Points\nPress The 'p' Button To Pause\nTry To Fly For As Long As Possible\nYou Have Three Shields, Good Luck" ,"Instructions", JOptionPane.INFORMATION_MESSAGE);
        }
        randomgenrun.go();
        
    }
    
    //watching for key events
    public void keyPressed(KeyEvent keyevent) {
        switch(keyevent.getKeyCode()) {
        case 32: // ' '
            if (!panel.start){
                panel.start = true;
            }
            else {
                panel.space = true;
            }
            break;
        case 80:
            panel.start=false;
            break;
        }
    }

    public void keyReleased(KeyEvent keyevent) {
        switch(keyevent.getKeyCode()) {
        case 32: // ' '
            panel.space = false;
            break;
        }
        
    }

    public void keyTyped(KeyEvent keyevent) {
    }
    
    //creating variables
    RandomGen panel;
    int high;
    int speed;
    boolean nhigh;
    
}