//This section does all the logic and draws componentslug

//import statments
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

public class RandomGen extends JPanel {

    public RandomGen() {
        //initializng puplic variables
        array = new int[101];
        legnth = 50;
        secs = 0;
        score = 0;
        multiplyer = 1;
        starpos1 = 200;
        starpos2 = 100;
        starpos3 = 25;
        starpos4 = 400;
        starpos5 = 475;
        starpos6 = 300;
        starposy1 = 200;
        starposy2 = 150;
        starposy3 = 250;
        starposy4 = 325;
        starposy5 = 350;
        starposy6 = 125;
        od = 0;
        obsheight = 500;
        obsypos = 200;
        speed = 0;
        time = 0;
        spacepress = 1;
        shippos = 250;
        mshow=0;
        multpos=500;
        multypos=200;
        speedup=0;
        speedupsecs=0;
        secsmin=0;
        shieldn=3;
        shieldc=0;
        jumpr=0;
        jumppos=500;
        jumpypos=200;
        jumpsec=0;
        builddis=0;
        shieldd=false;
        dirn = false;
        obsdisp = false;
        die = false;
        space = false;
        multshow=false;
        multshow1=false;
        shieldh=false;
        shieldup=false;
        pause=false;
        jump=false;
        jumpahead=false;
        shieldups=0;
        shieldpos=200;
        shieldxpos=500;
        gravup=0;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Random posy1 = new Random();
        int posy = 100 + posy1.nextInt(325);
        
        int xpos = 0;
        int arraynum = 0;
        
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 500, 500);
        
        //drawing stars
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos1, starposy1, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos1 + 2, starposy1 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos1 + 4, starposy1 + 4, 6, 6);
        starpos1 -= 0.5;
        if(starpos1 < 5) {
            starpos1 = 500;
            starposy1 = posy;
        }
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos2, starposy2, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos2 + 2, starposy2 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos2 + 4, starposy2 + 4, 6, 6);
        starpos2 -= 0.5;
        if(starpos2 < 5) {
            starpos2 = 500;
            starposy2 = posy;
        }
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos3, starposy3, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos3 + 2, starposy3 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos3 + 4, starposy3 + 4, 6, 6);
        starpos3 -= 0.5;
        if(starpos3 < 5) {
            starpos3 = 500;
            starposy3 = posy;
        }
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos4, starposy4, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos4 + 2, starposy4 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos4 + 4, starposy4 + 4, 6, 6);
        starpos4 -= 0.5;
        if(starpos4 < 5) {
            starpos4 = 500;
            starposy4 = posy;
        }
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos5, starposy5, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos5 + 2, starposy5 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos5 + 4, starposy5 + 4, 6, 6);
        starpos5 -= 0.5;
        if(starpos5 < 5) {
            starpos5 = 500;
            starposy5 = posy;
        }
        g.setColor(Color.DARK_GRAY);
        g.fillOval(starpos6, starposy6, 14, 14);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(starpos6 + 2, starposy6 + 2, 10, 10);
        g.setColor(Color.WHITE);
        g.fillOval(starpos6 + 4, starposy6 + 4, 6, 6);
        starpos6 -= 0.5;
        if(starpos6 < 5) {
            starpos6 = 500;
            starposy6 = posy;
        }
        //creating landscape
        //storing initial landscape
        g.setColor(Color.GREEN);
        if(secs == 0)
            do {
                if(arraynum > 100)
                    break;
                array[arraynum] = legnth;
                g.fillRect(xpos, 0, 5, array[arraynum]+builddis);
                g.fillRect(xpos, (320-builddis) + array[arraynum], 5, 200);
                arraynum++;
                xpos += 5;
                Random random3 = new Random();
                int l = 1 + random3.nextInt(4);
                if(legnth < 90 && !dirn)
                    legnth += l;
                if(legnth >= 90)
                    dirn = true;
                if(dirn)
                    if(legnth > 40)
                        legnth -= l;
                    else
                        dirn = false;
            } while(true);
        //creating new element at end
        if(secs > 0)
            do {
                if(arraynum > 99)
                    break;
                if(arraynum <= 99) {
                    array[arraynum] = array[arraynum + 1];
                    g.fillRect(xpos, 0, 5, array[arraynum]+builddis);
                    g.fillRect(xpos, (320-builddis) + array[arraynum], 5, 200);
                    arraynum++;
                    xpos += 5;
                }
                if(arraynum == 100) {
                    Random random4 = new Random();
                    int i1 = 1 + random4.nextInt(4);
                    if(legnth < 100 && !dirn)
                        legnth += i1;
                    if(legnth >= 100)
                        dirn = true;
                    if(dirn)
                        if(legnth > 50)
                            legnth -= i1;
                        else
                            dirn = false;
                    array[arraynum] = legnth;
                }
            } while(true);
        //creating barrier
        if(!obsdisp && !jumpahead) {
            Random random1 = new Random();
            od = 1 + random1.nextInt(50);
        }
        if(od == 25) {
            obsdisp = true;
            Random random2 = new Random();
            obsypos = 125 + random2.nextInt(75);
            od = 0;
        }
        if(obsdisp) {
            g.setColor(Color.GREEN);
            obsheight -= (4+speedup);
            g.fillRect(obsheight, obsypos, 10, 140);
        }
        if(obsheight < 5) {
            obsdisp = false;
            obsheight = 500;
        }
        //creating multiplier tokens
        if (!multshow && !jumpahead){
           Random mshow1=new Random();
           mshow= 1+ mshow1.nextInt(1800);   
        }
        if (mshow==900){
            if (!multshow1){
            Random multypos1=new Random();
            multypos=120+multypos1.nextInt(100);
            }
            multshow=false;
            multshow1=true;
            mshow=0;
        }
        if (multshow1){
            g.setColor(Color.YELLOW);
        g.fillOval(multpos, multypos, 50, 50);
        g.setColor(Color.GRAY);
        g.fillRect(multpos+13, multypos+10, 4, 30);
        int xpoints1[]= {multpos+13,multpos+19, multpos+29, multpos+23};
        int ypoints1[]= {multypos+10, multypos+10, multypos+40, multypos+40};
        int xpoints2[]= {multpos+23, multpos+29, multpos+39, multpos+33};
        int ypoints2[]= {multypos+40, multypos+40, multypos+10, multypos+10};
        g.fillPolygon(xpoints1, ypoints1, 4);
        g.fillPolygon(xpoints2, ypoints2, 4);
        g.fillRect(multpos+35, multypos+10, 4, 30);
        multpos-=(5+speedup);
        }
        if (multpos<5){
            multshow1=false;
            multpos=500;
        }
        //creating shieldup token
        if (shieldn<3 && !shieldup && !jumpahead){
        Random shieldups1= new Random();
        shieldups= 1+shieldups1.nextInt(3000);
        }
        if (shieldups==1500){
        shieldup=true;
        Random shieldpos1= new Random();
        shieldpos= 120+shieldpos1.nextInt(100);
        shieldups=0;
        }
        if (shieldup){
        g.setColor(Color.WHITE);
        g.fillRect(shieldxpos, shieldpos, 50, 50);
        g.setColor(Color.RED);
        g.fillRect(shieldxpos+20, shieldpos, 10, 50);
        g.fillRect(shieldxpos, shieldpos+20, 50, 10);
        shieldxpos-=(5+speedup);
        }
        if (shieldxpos<5){
            shieldup=false;
            shieldxpos=500;
        }
        //creating jump tokens
        if (!jump && !jumpahead){
            Random jumpr1= new Random();
            jumpr=1+jumpr1.nextInt(2400);
        }
        if (jumpr==1200){
           jump=true;
           Random jumpypos1=new Random();
           jumpypos=120+jumpypos1.nextInt(100);
           jumpr=0;
           
        }
        if (jump){
        g.setColor(Color.ORANGE);
        g.fillOval(jumppos, jumpypos, 40, 40);
        g.setColor(Color.YELLOW);
        g.fillOval(jumppos+3, jumpypos+3, 34, 34);
        g.setColor(Color.RED);
        g.fillRect(jumppos+10, jumpypos+19, 25, 2);
        int xpoints1[]= {jumppos+35,jumppos+35, jumppos+10, jumppos+10};
        int ypoints1[]= {jumpypos+19, jumpypos+21, jumpypos+12, jumpypos+8};
        int xpoints2[]= {jumppos+35, jumppos+35, jumppos+10, jumppos+10};
        int ypoints2[]= {jumpypos+19, jumpypos+21, jumpypos+32, jumpypos+28};
        g.fillPolygon(xpoints1, ypoints1, 4);
        g.fillPolygon(xpoints2, ypoints2, 4);   
        jumppos-=(5+speedup);
        }
        if (jumppos<5){
            jump=false;
            jumppos=500;
        }
        
        //checking if multiplier token hit
        if (multpos>35 && multpos<115){
            if (shippos>multypos && shippos<multypos+50 || shippos + 40 > multypos && shippos + 40 < multypos + 50){
                multiplyer++;
            multshow1=false;
            multpos=500;
            }
        }
        //checking if shieldup token hit
        if (shieldxpos>35 && shieldxpos<115){
            if (shippos>shieldpos && shippos<shieldpos+50 || shippos + 40 > shieldpos && shippos + 40 < shieldpos + 50){
                shieldn++;
            shieldup=false;
            shieldxpos=500;
            }
        }
        //checking if jump token hit
        if (jumppos>45 && jumppos<115){
            if (shippos>jumpypos && shippos<jumpypos+40 || shippos + 40 > jumpypos && shippos + 40 < jumpypos + 40){
                jumpahead=true;
            jump=false;
            jumppos=500;
            }
        }
        
        if (jumpahead){
        jumpsec++;
        speed=0;
        }
        if(jumpsec>800){
        jumpahead=false;
        jumpsec=0;
        }
        //setting power for spaceship
        if(!space && !jumpahead) {
            speed += (0.5+gravup)*(time / 50);
            time++;
            shippos = (int) (shippos + speed);
            spacepress = 1;
        }
        if(space && !jumpahead) {
            if(spacepress == 1) {
                time = 0;
                spacepress++;
            } else {
                speed -= ((4.25+(gravup*8))*time/50);
            }
            time++;
            shippos = (int) (shippos + speed);
            int thrust1x[]= {85, 95, 105};
            int thrust1y[]= {shippos+43, shippos+60, shippos+43};
            int thrust2x[]= {90, 95, 100};
            int thrust2y[]= {shippos+43, shippos+53, shippos+43};
            g.setColor(Color.ORANGE);
            g.fillPolygon(thrust1x, thrust1y, 3);
            g.setColor(Color.YELLOW);
            g.fillPolygon(thrust2x, thrust2y, 3);
        }
        //drawing ship
        g.setColor(Color.RED);
        g.fillRect(75, shippos, 40, 40);
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(75, shippos, 40, 5);
        g.fillRect(75, shippos, 5, 40);
        g.fillRect(110, shippos, 5, 40);
        g.setColor(Color.CYAN);
        g.fillOval(87, shippos+5, 16, 20);
        g.setColor(Color.GRAY);
        g.fillRect(85, shippos+30, 21, 15);
        //drawing shields
        if (shieldn==3){
            Color c = new Color(0,100,255,100);
            g.setColor(c);
            g.fillOval(65, shippos-10, 60, 60);
        }
        if (shieldn==2){         
            Color c = new Color(225,0,0,100);
            g.setColor(c);
            g.fillOval(65, shippos-10, 60, 60);
        }
        //checking if landscape hit
        if(shippos < array[19] || shippos < array[15] || shippos < array[23])
            shieldd=true;
        if(shippos > 280 + array[19] || shippos > 280 + array[15] || shippos > 280 + array[23])
            shieldd=true;
        //checking if barrier hit
        if(obsheight > 65 && obsheight < 115) {
            if(shippos > obsypos && shippos < obsypos + 140)
                shieldd=true;
            if(shippos + 40 > obsypos && shippos + 40 < obsypos + 140)
                shieldd=true;
        }
        if (jumpahead)
        shieldd=false;    
        
        if (shieldd && shieldc==0){
        shieldn--;
        shieldh=true;
        shieldd=false;
        }
        
        if (shieldh)
        shieldc+=1;       
        
        if (shieldc>50){
        shieldc=0;
        shieldh=false;
        shieldd=false;
        }
        
        if (shieldn==0)
            die=true;
        //drawing text
        score+= secs*multiplyer;
        secs=0;
        g.setColor(Color.BLACK);
        String s = String.format("%s", score);
        String m = String.format("%s", multiplyer);
        String lev = String.format("%s", speedup+1);
        String shi = String.format("%s", shieldn);
        g.drawString("Score:", 25, 450);
        g.drawString(s, 25, 470);
        g.drawString("Multpilyer:", 150, 450);
        g.drawString(m, 175, 470);
        g.drawString("Level:", 300, 450);
        g.drawString(lev, 315, 470);
        g.drawString("Shield Level:", 400, 450);
        g.drawString(shi, 425, 470);
        secs++;
        speedupsecs=score-secsmin;
        //creating speedup
        if (speedupsecs>4000){
            if (speedup<4){
            speedup++;
            }
            if (builddis<8) {
            builddis+=2;
            gravup+=.01;
            }
            speedupsecs=0;
            secsmin+=4000;
        }
    }
//creating variables
    int multiplyer;
    int score;
    int secs;
    int array[];
    int legnth;
    int starpos1;
    int starpos2;
    int starpos3;
    int starpos4;
    int starpos5;
    int starpos6;
    int starposy1;
    int starposy2;
    int starposy3;
    int starposy4;
    int starposy5;
    int starposy6;
    int od;
    int obsheight;
    int obsypos;
    int spacepress;
    float speed;
    float time;
    int shippos;
    int multpos;
    int multypos;
    int mshow;
    int speedup;
    int speedupsecs;
    int secsmin;
    int shieldn;
    int shieldc;
    int shieldups;
    int shieldpos;
    int shieldxpos;
    int jumpr;
    int jumppos;
    int jumpypos;
    int jumpsec;
    int builddis;
    float gravup;
    boolean dirn;
    boolean obsdisp;
    boolean die;
    boolean space;
    boolean multshow;
    boolean multshow1;
    boolean shieldd;
    boolean shieldh;
    boolean shieldup;
    boolean pause;
    boolean jump;
    boolean jumpahead;
}
